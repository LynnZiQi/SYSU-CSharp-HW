﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Todos.ViewModels;
//“空白页”项模板在 http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 上有介绍

namespace Todos
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        ViewModel myViewModel { get; set; }
        public MainPage()
        {
            this.InitializeComponent();
            var viewTitleBar = Windows.UI.ViewManagement.ApplicationView.GetForCurrentView().TitleBar;
            viewTitleBar.BackgroundColor = Windows.UI.Colors.CornflowerBlue;
            viewTitleBar.ButtonBackgroundColor = Windows.UI.Colors.CornflowerBlue;
            myViewModel = new ViewModel();
            DataContext = myViewModel;
        }
        private void checkbox1Check(object sender, RoutedEventArgs e)
        {
            line1.Opacity = 1;
        }
        private void checkbox1Uncheck(object sender, RoutedEventArgs e)
        {
            line1.Opacity = 0;
        }
        private void checkbox2Check(object sender, RoutedEventArgs e)
        {
            line2.Opacity = 1;
        }
        private void checkbox2Uncheck(object sender, RoutedEventArgs e)
        {
            line2.Opacity = 0;
        }
        private void AddAppBarButton_Click(object sender, RoutedEventArgs e)
        {
            //myViewModel.SaveData();
            Frame.Navigate(typeof(NewPage));
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {


            if (e.NavigationMode == NavigationMode.New)
            {
                // If this is a new navigation, this is a fresh launch so we can
                // discard any saved state
                ApplicationData.Current.LocalSettings.Values.Remove("TheWorkInProgress");
            }
            else
            {
                // Try to restore state if any, in case we were terminated
                if (ApplicationData.Current.LocalSettings.Values.ContainsKey("TheWorkInProgress"))
                {
                    var composite = ApplicationData.Current.LocalSettings.Values["TheWorkInProgress"] as ApplicationDataCompositeValue;
                    line1.Opacity = (double)composite["Field4"];
                    line2.Opacity = (double)composite["Field5"];
                    if(line1.Opacity == 1)
                    {
                        checkbox1.IsChecked = true;
                    }
                    if (line2.Opacity == 1)
                    {
                        checkbox2.IsChecked = true;
                    }
                    // We're done with it, so remove it
                    ApplicationData.Current.LocalSettings.Values.Remove("TheWorkInProgress");
                }
            }
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {


            bool suspending = ((App)App.Current).IsSuspending;
            if (suspending)
            {
                // Save volatile state in case we get terminated later on, then
                // we can restore as if we'd never been gone :)
                var composite = new ApplicationDataCompositeValue();
                composite["Field4"] = line1.Opacity;
                composite["Field5"] = line2.Opacity;
                ApplicationData.Current.LocalSettings.Values["TheWorkInProgress"] = composite;
            }
        }
    }
}
