﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Todos.Model;

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
namespace Todos.ViewModels
{
    class ViewModel : ViewModelBase
    {
        private string field1;
        public string Field1 { get { return field1; } set { Set(ref field1, value); } }

        private string field2;
        public string Field2 { get { return field2; } set { Set(ref field2, value); } }

        private DateTimeOffset field3;
        public DateTimeOffset Field3
        {
            get { return field3; }
            set { Set(ref field3, value); }
        }
        private double field4;
        public double Field4
        {
            get { return field4; }
            set { Set(ref field4, value); }
        }
        private double field5;
        public double Field5
        {
            get { return field5; }
            set { Set(ref field5, value); }
        }
        public void LoadData()
        {
            if (ApplicationData.Current.RoamingSettings.Values.ContainsKey("TheData"))
            {
                Models data = JsonConvert.DeserializeObject<Models>(
                    (string)ApplicationData.Current.RoamingSettings.Values["TheData"]);
                Field1 = data.Field1;
                Field2 = data.Field2;
                Field3 = data.Field3;
                Field4 = data.Field4;
                Field5 = data.Field5;
            }
            else
            {
                // New start, initialize the data
                Field1 = string.Empty;
                Field2 = string.Empty;
                Field3 = DateTimeOffset.Now;
                Field4 = 0.0;
                Field5 = 0.0;
            }
        }
       /* public void SaveData()
        {
            Models data = new Models { Field1 = this.Field1, Field2 = this.Field2, Field3 = this.Field3, Field4 = this.Field5, Field5 = this.Field5 };
            ApplicationData.Current.RoamingSettings.Values["TheData"] =
                JsonConvert.SerializeObject(data);
        }*/
    }
    }

