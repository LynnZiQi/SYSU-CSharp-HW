﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Todos.Model
{
    class Models
    {
        public string Field1 {
            get;
            set;
        }
        public string Field2
        {
            set;
            get;
        }
        public DateTimeOffset Field3 {
            set;
            get;
            }
        public double Field4
        {
            set;
            get;
        }
        public double Field5
        {
            set;
            get;
        }
    }
}
