﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

//“空白页”项模板在 http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 上有介绍

namespace APP1
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    ///
    /// 
   

    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void OnMouseDownPauseMedia(object sender, RoutedEventArgs e)
        {
            myMediaElement.Pause();
        }

        private void OnMouseDownPlayMedia(object sender, RoutedEventArgs e)
        {
            myMediaElement.Play();
        }

        private void OnMouseDownStopMedia(object sender, RoutedEventArgs e)
        {
            myMediaElement.Stop();
        }
        private void Element_MediaOpened(object sender, RoutedEventArgs e)
        {
            timelineSlider.Maximum = myMediaElement.NaturalDuration.TimeSpan.TotalSeconds;
        }
        private void Element_MediaEnded(object sender, RoutedEventArgs e)
        {
            myMediaElement.Stop();
        }
        async private void SetLocalMedia(object sender, RoutedEventArgs e)
        {
            var openPicker = new Windows.Storage.Pickers.FileOpenPicker();
            openPicker.SuggestedStartLocation =
            Windows.Storage.Pickers.PickerLocationId.VideosLibrary;
            openPicker.FileTypeFilter.Add(".wmv");
            openPicker.FileTypeFilter.Add(".mp4");
            openPicker.FileTypeFilter.Add(".mp3");
            var file = await openPicker.PickSingleFileAsync();
           if (file != null)
            {
                var stream = await file.OpenAsync(Windows.Storage.FileAccessMode.Read);
                // mediaControl is a MediaElement defined in XAML
                myMediaElement.SetSource(stream, file.ContentType);
                myMediaElement.Play();
            }
        }

        private void FullWindow_Click(object sender, object e)
        {
            myMediaElement.IsFullWindow = !myMediaElement.IsFullWindow;
        }
        //todo
       // private void ChangeMediaVolume(object sender, RoutedEvent args)
   //     {
     //       myMediaElement.Volume = (double)volumeSlider.Value;
     //   }
    }

    class MusicConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            return ((TimeSpan)value).TotalSeconds;
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            return TimeSpan.FromSeconds((double)value);
            
        }
    }
  /*  class VolumeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {


           

        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
          
           
        }
    }*/

}
