﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Todo_2.Models;
using Windows.ApplicationModel.DataTransfer;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Notifications;
using Windows.Storage;
using Windows.ApplicationModel;
using System.Diagnostics;
using Windows.Storage.Streams;
using System.Xml;
using Windows.UI.Notifications;
using Microsoft.Toolkit.Uwp.Notifications;
//“空白页”项模板在 http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 上有介绍

namespace Todo_2
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    /// 

    public sealed partial class MainPage : Page
    {

      //  private StorageFile _tempExportFile;
        DataTransferManager dataTransferManager = DataTransferManager.GetForCurrentView();
        public MainPage()
        {
            
       
            this.InitializeComponent();
            var viewTitleBar = Windows.UI.ViewManagement.ApplicationView.GetForCurrentView().TitleBar;
            viewTitleBar.BackgroundColor = Windows.UI.Colors.CornflowerBlue;
            viewTitleBar.ButtonBackgroundColor = Windows.UI.Colors.CornflowerBlue;
            this.ViewModel = new ViewModels.TodoItemViewModel();
            this.NavigationCacheMode = Windows.UI.Xaml.Navigation.NavigationCacheMode.Required;
            DataTransferManager dataTransferManager = DataTransferManager.GetForCurrentView();
            dataTransferManager.DataRequested += DataRequested;
        }
        
       
        ViewModels.TodoItemViewModel ViewModel { get; set; }
        private async void create_Click(object sender, RoutedEventArgs e)
        {
            if (title.Text == "" && describe.Text == "")
            {
                var messageDialog = new MessageDialog("标题和描述不能为空!");
                messageDialog.Commands.Add(new UICommand("OK"));
                messageDialog.ShowAsync();
            }
            else if (title.Text == "")
            {
                var messageDialog = new MessageDialog("标题不能为空!");
                messageDialog.Commands.Add(new UICommand("OK"));
                messageDialog.ShowAsync();
            }
            else if (describe.Text == "")
            {
                var messageDialog = new MessageDialog("描述不能为空!");
                messageDialog.Commands.Add(new UICommand("OK"));
                messageDialog.ShowAsync();
            }

            else if (date.Date < DateTime.Today)
            {
                var messageDialog = new MessageDialog("日期至少为今天!");
                messageDialog.Commands.Add(new UICommand("OK"));
                messageDialog.ShowAsync();
            }
            else
            {
                if (createButton.Content.ToString() == "Create")
                {
                    var messageDialog = new MessageDialog("成功!");
                    messageDialog.Commands.Add(new UICommand("OK"));
                    ViewModel.AddTodoItem(title.Text, describe.Text, date.Date);
                    tile();
                    await messageDialog.ShowAsync();  //按确定之后清除原有信息
                    title.Text = "";
                    describe.Text = "";
                    date.Date = DateTime.Today;
                    
                    Frame.Navigate(typeof(MainPage), ViewModel);  //可以设置跳回主页面
                }
                else if (createButton.Content.ToString() == "Update")
                {
                    TodoItem newitem = new TodoItem(title.Text, describe.Text, date.Date);


                    var messageDialog = new MessageDialog("成功!");
                    messageDialog.Commands.Add(new UICommand("OK"));
                    tile();
                    await messageDialog.ShowAsync();  //按确定之后清除原有信息

                    title.Text = "";
                    describe.Text = "";
                    date.Date = DateTime.Today;

                    ViewModel.UpdateTodoItem(newitem.id, newitem.title, newitem.description, newitem.date);
                   
                    Frame.Navigate(typeof(MainPage), ViewModel);  //可以设置跳回主页面
                }
            }
        }
        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            //  var messageDialog = new MessageDialog("清除成功!");
            //   messageDialog.Commands.Add(new UICommand("OK"));
            //  await messageDialog.ShowAsync();  //按确定之后清除原有信息
            title.Text = "";
            describe.Text = "";
            date.Date = DateTime.Today;

        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            

            if (e.Parameter.GetType() == typeof(ViewModels.TodoItemViewModel))
            {
                this.ViewModel = (ViewModels.TodoItemViewModel)(e.Parameter);
            }
        }

        private void TodoItem_ItemClicked(object sender, ItemClickEventArgs e)
        {
            ViewModel.SelectedItem = (Models.TodoItem)(e.ClickedItem);
          
            if (Window.Current.Bounds.Width < 800)
            Frame.Navigate(typeof(NewPage), ViewModel);
            else
            {
                
                title.Text = ViewModel.SelectedItem.title;
                describe.Text = ViewModel.SelectedItem.description;
                date.Date = ViewModel.SelectedItem.date;
                createButton.Content = "Update";
                
            }
        }

        private void AddAppBarButton_Click(object sender, RoutedEventArgs e)
        {
            if (Window.Current.Bounds.Width > 800)
                return;
           
            Frame.Navigate(typeof(NewPage), ViewModel);
        }

        private void CheckBox2_checked(object sender, RoutedEventArgs e)
        {


     // if (ViewModel.SelectedItem != null)
      //      {

//
         //     this.ViewModel.SelectedItem.completed = true;
      //this.ViewModel.SelectedItem = null;
             //   if (Window.Current.Bounds.Width < 800)
             //   Frame.Navigate(typeof(NewPage), ViewModel);
              //  else
        //  Frame.Navigate(typeof(MainPage), ViewModel);
   

    //        }

        }




        private string sharetitle = "", sharedescription = "";
        private StorageFile shareimg;
        private async void share_click(object sender, RoutedEventArgs e)
        {
            
          var dc = (sender as FrameworkElement).DataContext;
            var item = (ToDoListView.ContainerFromItem(dc) as ListViewItem).Content as TodoItem;
            sharetitle = item.title;
            sharedescription = "Todo's description: " + item.description;

            shareimg = await Package.Current.InstalledLocation.GetFileAsync("Assets\\1e6039402d9be31d.jpg");
            DataTransferManager.ShowShareUI();
        }
        private void DataRequested(DataTransferManager sender, DataRequestedEventArgs e)
        {
            Debug.WriteLine(e.Request.ToString());
            DataRequest request = e.Request;
            DataPackage requestData = request.Data;
            requestData.Properties.Title = sharetitle;
            requestData.SetText(sharedescription);

            // Because we are making async calls in the DataRequested event handler,
            //  we need to get the deferral first.
            DataRequestDeferral deferral = request.GetDeferral();

            // Make sure we always call Complete on the deferral.
            try
            {
                requestData.SetBitmap(RandomAccessStreamReference.CreateFromFile(shareimg));
            }
            finally
            {
                deferral.Complete();
            }
        }
        private void CheckBox2_unchecked(object sender, RoutedEventArgs e)
        {
//
          //  if (ViewModel.SelectedItem != null)
         //   {
           //     this.ViewModel.SelectedItem.completed = false;
   //this.ViewModel.SelectedItem = null;
                // if (Window.Current.Bounds.Width < 800)
             //        Frame.Navigate(typeof(NewPage), ViewModel);
              //   else
       //   Frame.Navigate(typeof(MainPage), ViewModel);


      //      }
        }
        public void tile()
        {
            Windows.Data.Xml.Dom.XmlDocument xdoc = new Windows.Data.Xml.Dom.XmlDocument();
            xdoc.LoadXml(File.ReadAllText("tile.xml"));
            Windows.Data.Xml.Dom.XmlNodeList tilelist = xdoc.GetElementsByTagName("text");
            tilelist[0].InnerText = title.Text;
            tilelist[2].InnerText = title.Text;
            tilelist[4].InnerText = title.Text;
            tilelist[1].InnerText = describe.Text;
            tilelist[3].InnerText = describe.Text;
            tilelist[5].InnerText = describe.Text;
            tilelist[6].InnerText = title.Text;
            tilelist[7].InnerText = describe.Text;
            TileNotification notification = new TileNotification(xdoc);
            TileUpdateManager.CreateTileUpdaterForApplication().EnableNotificationQueue(true);
            TileUpdater updater = TileUpdateManager.CreateTileUpdaterForApplication();
            updater.Update(notification);

        }


    }
}
