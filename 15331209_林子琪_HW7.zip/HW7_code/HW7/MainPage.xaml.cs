﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

//“空白页”项模板在 http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 上有介绍

namespace HW7
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void SearchPhone(AutoSuggestBox sender, AutoSuggestBoxQuerySubmittedEventArgs args)
        {
            if (Search.Text == "")
            {
                await new MessageDialog("手机号码不能为空！").ShowAsync();
                return;
            }
            
            Uri url = new Uri(@"http://opendata.baidu.com/api.php?query=" + Search.Text.Trim() + "&co=&resource_id=6004&t=1460125093359&ie=utf8&oe=gbk&cb=op_aladdin_callback&format=json&tn=baidu&cb=jQuery11020106542830829915_1460112569047&_=1460112569072");
            try
            {
                
                Windows.Web.Http.HttpClient httpclient = new Windows.Web.Http.HttpClient();
                var Res = await httpclient.GetAsync(url);
                //请求数据
                Res.EnsureSuccessStatusCode();
                var ResBody = await Res.Content.ReadAsStringAsync();
                //读取数据流，以字符串形式
                int start = ResBody.IndexOf('{');
                int end = ResBody.LastIndexOf(')');
                //需要截取中间的信息
                ResBody = ResBody.Substring(start, end - start);
                var body = new Dictionary<string, object>();
                //Dictionary，相等比较器
                body = JsonConvert.DeserializeObject<Dictionary<string, object>>(ResBody);
                //获取Json数据对象
                var arr = body["data"] as Newtonsoft.Json.Linq.JArray;
                //以数组的形式，存储对应的属性
                try
                {  //合法输入，进行查询
                    var obj = arr[0];
                    string result = "";
                    result += Search.Text.Trim() + "\n";
                    result += obj["prov"] + " " + obj["city"] + "\n";
                    result += obj["type"].ToString() + "\n";
                    await new MessageDialog(result).ShowAsync();
                    Search.Text = "";
                   
                }
                catch (Exception)
                {
                    await new MessageDialog("号码不存在！请重新输入").ShowAsync();
                    Search.Text = "";
             
                   
                    return;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }
    }
}
