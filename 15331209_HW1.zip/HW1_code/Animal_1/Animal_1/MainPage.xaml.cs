﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

//“空白页”项模板在 http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 上有介绍

namespace Animal_1
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
        private int times =0;
        private delegate string AnimalSaying(object sender, myEventArgs e);
        private event AnimalSaying Say;
        class myEventArgs : EventArgs
        {
            public int count = 0;
            public myEventArgs(int count)
            {
                this.count = count;
            }
        }
        interface Animal
        {
            //方法
            string saying(object sender, myEventArgs e);
            //属性
        }
        class cat : Animal
        {
            TextBlock word;
            public cat(TextBlock w)
            {
                this.word = w;
            }
            public string saying(object sender, myEventArgs e)
            {
                this.word.Text += "Cat : I am a cat.\n";
                return "";
            }
        }
        class dog : Animal
        {
            TextBlock word;
            public dog(TextBlock w)
            {
                this.word = w;
            }
            public string saying(object sender, myEventArgs e)
            {
                this.word.Text += "Dog : I am a dog.\n";
                return "";
            }
        }
        class pig : Animal
        {
            TextBlock word;
            public pig(TextBlock w)
            {
                this.word = w;
            }
            public string saying(object sender, myEventArgs e)
            {
                this.word.Text += "Pig : I am a pig.\n";
                return "";
            }

        }
        private cat _Cat;
        private dog _Dog;
        private pig _Pig;
    //    private void button_Click(object sender, RoutedEventArgs e)
     //   {

            /* if (times == 0)
             {
                 textBlock.Text = ""; //初始状态，空白
                 _Cat = new cat(textBlock);
                 _Dog = new dog(textBlock);
                 _Pig = new pig(textBlock);
             } 
             Random digit = new Random(); //随机数
             int key = digit.Next(0, 3);
           //  textBlock.Text = "hello world";
             if (key == 0)
             {
                 Say += new AnimalSaying(_Cat.saying);
                 Say(this, new myEventArgs(times++));
                 Say -= new AnimalSaying(_Cat.saying);
             }
             else if (key == 1)
             {
                 Say += new AnimalSaying(_Dog.saying);
                 Say(this, new myEventArgs(times++));
                 Say -= new AnimalSaying(_Dog.saying);
             }
             else if (key == 2)
             {
                 Say += new AnimalSaying(_Pig.saying);
                 Say(this, new myEventArgs(times++));
                 Say -= new AnimalSaying(_Pig.saying);
             }
         }*/
    //        textBlock.Text = "hello";
    //    }


        private void button_Click(object sender, RoutedEventArgs e)
        {

            if (times == 0)
             {
                 textBlock.Text = ""; //初始状态，空白
                 _Cat = new cat(textBlock);
                 _Dog = new dog(textBlock);
                 _Pig = new pig(textBlock);
             } 
             Random digit = new Random(); //随机数
             int key = digit.Next(0, 3);
           //  textBlock.Text = "hello world";
             if (key == 0)
             {
                 Say += new AnimalSaying(_Cat.saying);
                 Say(this, new myEventArgs(times++));
                 Say -= new AnimalSaying(_Cat.saying);
             }
             else if (key == 1)
             {
                 Say += new AnimalSaying(_Dog.saying);
                 Say(this, new myEventArgs(times++));
                 Say -= new AnimalSaying(_Dog.saying);
             }
             else if (key == 2)
             {
                 Say += new AnimalSaying(_Pig.saying);
                 Say(this, new myEventArgs(times++));
                 Say -= new AnimalSaying(_Pig.saying);
             }
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            string animal = textBox.Text.ToString();
          //  if (times == 0)
            //{
           //     textBlock.Text = ""; //初始状态，空白
           //     _Cat = new cat(textBlock);
           //     _Dog = new dog(textBlock);
           //     _Pig = new pig(textBlock);
          //  }
            if (animal == "cat" || animal == "Cat")
            {
                _Cat = new cat(textBlock);
                Say += new AnimalSaying(_Cat.saying);
                Say(this, new myEventArgs(times++));
                Say -= new AnimalSaying(_Cat.saying);
                textBox.Text = "";
               
            } else if (animal == "pig" || animal == "Pig")
            {
                _Pig = new pig(textBlock);
                Say += new AnimalSaying(_Pig.saying);
                Say(this, new myEventArgs(times++));
                Say -= new AnimalSaying(_Pig.saying);
                textBox.Text = "";
            } else if (animal == "dog" || animal == "Dog")
            {
                _Dog = new dog(textBlock);
                Say += new AnimalSaying(_Dog.saying);
                Say(this, new myEventArgs(times++));
                Say -= new AnimalSaying(_Dog.saying);
                textBox.Text = "";
            } else
            {
                textBox.Text = "";
            }
        }
    }
}
